document.getElementById("toggleTheme").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    document.body.classList.toggle("light");
});

// Comentários
const form = document.getElementById("commentForm");
const input = document.getElementById("commentInput");
const list = document.getElementById("commentList");

form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (input.value.trim() !== "") {
        const li = document.createElement("li");
        li.textContent = input.value;
        list.appendChild(li);
        input.value = "";
    }
});
